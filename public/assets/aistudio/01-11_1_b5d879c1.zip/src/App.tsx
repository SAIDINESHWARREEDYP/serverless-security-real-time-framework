import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Header, FeatureTabId } from './components/Header.tsx';
import { SimulationControl } from './components/SimulationControl.tsx';
import { AuditLogStream } from './components/AuditLogStream.tsx';
import { SecurityArchitectureModal } from './components/SecurityArchitectureModal.tsx';
import { CloudGuideModal } from './components/CloudGuideModal.tsx';
import { AuthModal } from './components/AuthModal.tsx';
import { ThreatSummaryCard } from './components/ThreatSummaryCard.tsx';
import { SystemHealthDashboard } from './components/SystemHealthDashboard.tsx';
import { AdminCommandCenter } from './components/AdminCommandCenter.tsx';
import { AnomalyAlertBanner } from './components/AnomalyAlertBanner.tsx';
import { GuestPortal } from './components/GuestPortal.tsx';
import { ZeroTrustLoginGateway } from './components/ZeroTrustLoginGateway.tsx';
import { AccessRestrictedCard } from './components/AccessRestrictedCard.tsx';
import { SecurityReportModal } from './components/SecurityReportModal.tsx';
import { UserDatabaseModal } from './components/UserDatabaseModal.tsx';
import { DeveloperWorkbench } from './components/DeveloperWorkbench.tsx';
import { AICloudThreatShield } from './components/AICloudThreatShield.tsx';
import { EdgeTopologyGraphic } from './components/EdgeTopologyGraphic.tsx';
import { SidebarNavigation } from './components/SidebarNavigation.tsx';
import { RbacManagementModal } from './components/RbacManagementModal.tsx';
import { FunctionInventoryExplorer } from './components/FunctionInventoryExplorer.tsx';
import { IncidentManagementConsole } from './components/IncidentManagementConsole.tsx';
import { ApiTestingConsole } from './components/ApiTestingConsole.tsx';
import { SystemConfigSettingsModal } from './components/SystemConfigSettingsModal.tsx';
import { HelpTechnicalDocsModal } from './components/HelpTechnicalDocsModal.tsx';
import { useRealtimeMonitor } from './hooks/useRealtimeMonitor.ts';
import { useTheme } from './context/ThemeContext.tsx';
import { getSectionMetaForTab } from './utils/sectionThemes.ts';
import {
  User,
  FunctionRule,
  SecurityAuditLog,
  TerminalLogEntry,
  SystemOverview,
  AuthSession,
  SecurityPolicyConfig,
  AnomalyAlert
} from './types.ts';
import {
  ShieldCheck,
  UserCheck,
  UserPlus,
  Key,
  Database,
  Plus,
  Trash2,
  Lock,
  ArrowRight,
  Shield,
  Layers,
  Sparkles,
  Cloud,
  ExternalLink,
  Bot,
  FileText
} from 'lucide-react';

export default function App() {
  const { theme } = useTheme();
  const [users, setUsers] = useState<User[]>([
    { id: 'usr_secops_admin', username: 'secops_admin', password_hash: 'ZeroTrust_2026', role: 'Admin', base_risk_score: 0 },
    { id: 'usr_cloud_dev', username: 'cloud_dev', password_hash: 'ZeroTrust_2026', role: 'Developer', base_risk_score: 15 },
    { id: 'usr_auditor_guest', username: 'auditor_guest', password_hash: 'ZeroTrust_2026', role: 'Guest', base_risk_score: 30 },
    { id: 'usr_threat_actor', username: 'threat_actor', password_hash: 'ZeroTrust_2026', role: 'Guest', base_risk_score: 70 }
  ]);

  const [rules, setRules] = useState<FunctionRule[]>([
    { id: 1, current_function: 'login', allowed_next_function: 'getDashboardMetrics' },
    { id: 2, current_function: 'getDashboardMetrics', allowed_next_function: 'viewSecurityLogs' },
    { id: 3, current_function: 'viewSecurityLogs', allowed_next_function: 'deployWorkerCode' },
    { id: 4, current_function: 'deployWorkerCode', allowed_next_function: 'updateSystemPolicy' },
    { id: 5, current_function: 'viewSecurityLogs', allowed_next_function: 'rotateEncryptionKeys' },
    { id: 6, current_function: 'rotateEncryptionKeys', allowed_next_function: 'purgeColdStorageBackups' }
  ]);

  const [logs, setLogs] = useState<SecurityAuditLog[]>([]);
  const [selectedUser, setSelectedUser] = useState<string>('secops_admin');
  const [selectedRoute, setSelectedRoute] = useState<string>('getDashboardMetrics');
  const [isFiring, setIsFiring] = useState<boolean>(false);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [isResetting, setIsResetting] = useState<boolean>(false);
  const [isDbModalOpen, setIsDbModalOpen] = useState<boolean>(false);
  const [isCloudGuideOpen, setIsCloudGuideOpen] = useState<boolean>(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [isSecurityReportOpen, setIsSecurityReportOpen] = useState<boolean>(false);
  const [isUserDbModalOpen, setIsUserDbModalOpen] = useState<boolean>(false);
  const [isRbacModalOpen, setIsRbacModalOpen] = useState<boolean>(false);
  const [isConfigModalOpen, setIsConfigModalOpen] = useState<boolean>(false);
  const [isDocsModalOpen, setIsDocsModalOpen] = useState<boolean>(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(false);
  const [terminalLogs, setTerminalLogs] = useState<TerminalLogEntry[]>([]);

  // Calculate pending users count for notification badges
  const pendingApprovalCount = useMemo(() => {
    return users.filter(u => u.status === 'PENDING_APPROVAL').length;
  }, [users]);

  // Navigation: Active Feature Tab
  const [activeTab, setActiveTab] = useState<FeatureTabId>('admin');
  const currentSectionMeta = useMemo(() => getSectionMetaForTab(activeTab), [activeTab]);

  // Authenticated session state - initialized to null so Zero-Trust Login Gateway is displayed first
  const [currentSession, setCurrentSession] = useState<AuthSession | null>(null);

  // Granular logging & state transition monitor for authentication lifecycle
  useEffect(() => {
    if (currentSession) {
      console.log('%c[AUTH_STATE_TRANSITION] ✅ Authenticated Session Active', 'color: #10b981; font-weight: bold;', {
        username: currentSession.user.username,
        role: currentSession.user.role,
        status: currentSession.user.status,
        loginTime: currentSession.loginTime,
        mfaMethod: currentSession.mfaMethod || 'authenticator',
        tokenPreview: currentSession.token ? `${currentSession.token.slice(0, 18)}...` : 'NONE',
        expiresInSeconds: currentSession.expiresInSeconds,
        timestamp: new Date().toISOString()
      });
    } else {
      console.log('%c[AUTH_STATE_TRANSITION] 🔒 Unauthenticated State (Zero-Trust Gateway Gate Active)', 'color: #f59e0b; font-weight: bold;', {
        timestamp: new Date().toISOString()
      });
    }
  }, [currentSession]);

  // Dynamic policy configuration
  const [policyConfig, setPolicyConfig] = useState<SecurityPolicyConfig>({
    maxRiskThreshold: 75,
    sequenceViolationPenalty: 40,
    enforceStrictSequence: true
  });

  // Real-time SSE streaming monitor with fallback
  const handleRealtimeNewLog = useCallback((newLog: SecurityAuditLog) => {
    setLogs(prev => {
      if (prev.some(l => l.id === newLog.id)) return prev;
      return [newLog, ...prev].slice(0, 500);
    });
    setTerminalLogs(prev => [
      ...prev,
      {
        id: Math.random().toString(36).substring(2, 9),
        timestamp: new Date().toLocaleTimeString(),
        type: newLog.status === 'ALLOWED' ? 'success' : 'alert',
        text: `[SSE LIVE] ${newLog.status}: ${newLog.username} -> ${newLog.requested_function} (Risk: ${newLog.calculated_risk}%)`
      }
    ]);
  }, []);

  const realtime = useRealtimeMonitor({
    onNewLog: handleRealtimeNewLog
  });

  // IAM inline form state for real-time any user
  const [inlineUsername, setInlineUsername] = useState('');
  const [inlineRole, setInlineRole] = useState<'Admin' | 'Developer' | 'Guest'>('Developer');
  const [inlineRisk, setInlineRisk] = useState<number>(20);
  const [inlineLoading, setInlineLoading] = useState(false);
  const [inlineMsg, setInlineMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Architecture inline new rule state
  const [newRuleCurrent, setNewRuleCurrent] = useState('login');
  const [newRuleNext, setNewRuleNext] = useState('getDashboardMetrics');

  // Network connectivity status derived from SSE monitor
  const connectionStatus = useMemo<'connected' | 'syncing' | 'reconnecting'>(() => {
    if (realtime.connectionStatus === 'LIVE_STREAMING') return 'connected';
    if (realtime.connectionStatus === 'POLLING_FALLBACK') return 'syncing';
    return 'reconnecting';
  }, [realtime.connectionStatus]);

  // Real-time Anomaly Alert State
  const [acknowledgedAlertIds, setAcknowledgedAlertIds] = useState<Set<string>>(new Set());

  // Derive active anomalies dynamically from audit logs & users
  const anomalyAlerts = useMemo<AnomalyAlert[]>(() => {
    const alerts: AnomalyAlert[] = [];
    const seen = new Set<string>();

    // 1. Scan blocked logs for high-risk / Markov / RBAC anomalies
    for (const log of logs) {
      if (log.status === 'BLOCKED') {
        const key = `${log.username}-${log.requested_function}-${log.timestamp}`;
        if (!seen.has(key)) {
          seen.add(key);

          const isRbac = log.reason.includes('RBAC Breach') || log.reason.includes('Unauthorized role');
          const isSequence = log.reason.includes('Abnormal invocation order') || log.reason.includes('sequence');
          const isCriticalRisk = log.calculated_risk >= (policyConfig?.maxRiskThreshold ?? 75);
          const isLockdown = log.reason.includes('LOCKDOWN');

          const alertType = isRbac
            ? 'PRIVILEGE_ESCALATION'
            : isSequence
            ? 'SEQUENCE_VIOLATION'
            : isCriticalRisk
            ? 'CRITICAL_RISK'
            : 'BRUTE_FORCE_ATTEMPT';

          const severity = isCriticalRisk || isLockdown ? 'CRITICAL' : isRbac ? 'HIGH' : 'MEDIUM';

          alerts.push({
            id: `alert_${log.id}`,
            timestamp: log.timestamp,
            type: alertType,
            severity,
            username: log.username,
            endpoint: log.requested_function,
            riskScore: log.calculated_risk,
            message: log.reason,
            mitigation: 'Cloudflare Edge Interceptor 403 Suspended',
            acknowledged: acknowledgedAlertIds.has(`alert_${log.id}`)
          });
        }
      }
    }

    // 2. Scan users with quarantined or abnormal base risk
    for (const user of users) {
      if (user.base_risk_score >= 80) {
        const key = `user_quarantine_${user.username}`;
        if (!seen.has(key)) {
          seen.add(key);
          alerts.push({
            id: key,
            timestamp: 'Policy Rule',
            type: 'CRITICAL_RISK',
            severity: 'CRITICAL',
            username: user.username,
            endpoint: 'Global Edge Perimeter',
            riskScore: user.base_risk_score,
            message: `Principal [${user.username}] holds critical base risk (${user.base_risk_score}%) — flagged for quarantine.`,
            mitigation: 'Administrative Quarantine Active',
            acknowledged: acknowledgedAlertIds.has(key)
          });
        }
      }
    }

    return alerts.slice(0, 10);
  }, [logs, users, policyConfig, acknowledgedAlertIds]);

  const handleAcknowledgeAlert = (id: string) => {
    setAcknowledgedAlertIds(prev => new Set(prev).add(id));
  };

  const handleQuarantineUser = async (username: string) => {
    try {
      const res = await fetch(`/api/system/users/${encodeURIComponent(username)}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ base_risk_score: 100 })
      });
      if (res.ok) {
        await fetchOverview();
        addTerminalLog('alert', `[SECOPS] Principal [${username}] has been quarantined (Base Risk: 100%).`);
      }
    } catch (e: any) {
      addTerminalLog('error', `[SECOPS] Quarantine action failed: ${e?.message || String(e)}`);
    }
  };

  const [isEmergencyLockdown, setIsEmergencyLockdown] = useState<boolean>(false);

  // 1. Enterprise Drill: Credential Stuffing Wave
  const handleRunCredentialStuffing = async () => {
    addTerminalLog('alert', '[DRILL] ⚡ Initiating Enterprise Credential Stuffing Wave (3 simulated automated bursts)...');
    try {
      const sprayTargets = ['threat_actor', 'unknown_botnet_42', 'auditor_guest'];
      for (const target of sprayTargets) {
        addTerminalLog('post', `[DRILL BURST] Simulating unauthorized automated login for [${target}]...`);
        const res = await fetch('/api/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username: target, password: 'INVALID_BREACHED_PASSWORD_2026' })
        });
        const data = await res.json();
        if (!data.success) {
          addTerminalLog('alert', `[DRILL MITIGATED] Zero-Trust Perimeter intercepted [${target}]: ${data.error}`);
        }
      }
      await fetchOverview();
      addTerminalLog('success', '[DRILL COMPLETED] Credential Stuffing wave completely deflected by edge rate-limits.');
    } catch (err: any) {
      addTerminalLog('error', `[DRILL FAILED] ${err?.message || String(err)}`);
    }
  };

  // 2. Enterprise Drill: Lateral Movement Exploit (out of order sequence)
  const handleRunLateralMovementDrill = async () => {
    addTerminalLog('alert', '[DRILL] 🔀 Testing Lateral Movement & Markov Sequence Anomaly detection...');
    try {
      addTerminalLog('post', '[DRILL] Authenticating as Tier 1 Guest [auditor_guest]...');
      const authRes = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: 'auditor_guest', password: 'ZeroTrust_2026', skipMfa: true })
      });
      const authData = await authRes.json();
      if (!authData.token) {
        addTerminalLog('error', '[DRILL] Auth failed for guest.');
        return;
      }
      addTerminalLog('alert', '[DRILL] Invariant Violation Attempt: Guest calling /api/purgeColdStorageBackups (Skipping login -> metrics sequence)...');
      const exploitRes = await fetch('/api/purgeColdStorageBackups', {
        method: 'GET',
        headers: { Authorization: `Bearer ${authData.token}` }
      });
      const exploitData = await exploitRes.json();
      if (exploitRes.status !== 200) {
        addTerminalLog('alert', `[DRILL INTERCEPTED] Edge Interceptor blocked lateral jump: ${exploitData.error}`);
        if (exploitData.metrics) {
          addTerminalLog('metric', `[DRILL PENALTY] Composite Risk: ${exploitData.metrics.riskScore}% (Markov Drift + RBAC breach detected).`);
        }
      }
      await fetchOverview();
      addTerminalLog('success', '[DRILL COMPLETED] Autonomous Markov Interceptor successfully contained lateral movement.');
    } catch (err: any) {
      addTerminalLog('error', `[DRILL FAILED] ${err?.message || String(err)}`);
    }
  };

  // 3. Enterprise Drill: Toggle Emergency Lockdown
  const handleToggleEmergencyLockdown = async () => {
    const nextState = !isEmergencyLockdown;
    setIsEmergencyLockdown(nextState);
    const newThreshold = nextState ? 25 : 75;
    try {
      await handleUpdatePolicyConfig({
        ...policyConfig,
        maxRiskThreshold: newThreshold
      });
      if (nextState) {
        addTerminalLog('alert', '[PERIMETER] 🚨 EMERGENCY ZERO-TRUST LOCKDOWN ENGAGED! Max Risk Cutoff set to 25% across all edge nodes.');
      } else {
        addTerminalLog('success', '[PERIMETER] Standard operational baseline restored. Max Risk Cutoff normalized to 75%.');
      }
    } catch (err: any) {
      addTerminalLog('error', `[PERIMETER LOCKDOWN ERROR] ${err?.message || String(err)}`);
    }
  };

  const addTerminalLog = useCallback((type: TerminalLogEntry['type'], text: string) => {
    setTerminalLogs((prev) => [
      ...prev,
      {
        id: Math.random().toString(36).substring(2, 9),
        timestamp: new Date().toLocaleTimeString(),
        type,
        text
      }
    ]);
  }, []);

  // Fetch system overview safely with graceful retry handling
  const fetchOverview = useCallback(async () => {
    setIsRefreshing(true);
    try {
      const res = await fetch('/api/system/overview', {
        headers: { Accept: 'application/json' }
      });
      if (res.ok) {
        const data: SystemOverview = await res.json();
        if (data && Array.isArray(data.users)) setUsers(data.users);
        if (data && Array.isArray(data.rules)) setRules(data.rules);
        if (data && Array.isArray(data.auditEvents) && data.auditEvents.length > 0) {
          setLogs(data.auditEvents);
        } else if (data && Array.isArray(data.logs)) {
          setLogs(data.logs);
        }
        if (data && data.policyConfig) setPolicyConfig(data.policyConfig);
      }
    } catch {
      // Non-blocking connection retry (e.g. during server reload or brief offline pause)
    } finally {
      setIsRefreshing(false);
    }
  }, []);

  useEffect(() => {
    let isMounted = true;
    const executeFetch = async () => {
      if (!isMounted) return;
      await fetchOverview();
    };

    executeFetch();
    const interval = setInterval(executeFetch, 4000);
    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, [fetchOverview]);

  // Initial welcome logs
  useEffect(() => {
    addTerminalLog('info', '[INIT] Serverless Security Verification Framework initialized.');
    addTerminalLog('info', '[RBAC] Cloudflare Edge Interceptor rule matrices loaded.');
    addTerminalLog('success', '[READY] Security simulation and audit pipeline online.');
  }, [addTerminalLog]);

  // Update policy configuration
  const handleUpdatePolicyConfig = async (newConfig: SecurityPolicyConfig) => {
    try {
      const res = await fetch('/api/system/policy-config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newConfig)
      });
      if (res.ok) {
        const data = await res.json();
        setPolicyConfig(data.policyConfig);
        addTerminalLog('success', `[POLICY] Security rule parameters updated: Max Risk Cutoff = ${data.policyConfig.maxRiskThreshold}%, Sequence Penalty = +${data.policyConfig.sequenceViolationPenalty}%`);
      }
    } catch (err: any) {
      addTerminalLog('error', `[POLICY] Failed to update parameters: ${err?.message || String(err)}`);
    }
  };

  // Execute Pipeline simulation
  const handleFirePipeline = async (user: string, route: string) => {
    setIsFiring(true);
    setTerminalLogs([]);

    addTerminalLog('info', `[INFO] Request initiated for principal [${user}] via edge security interceptor...`);

    try {
      addTerminalLog('post', `[POST] Acquiring verified Bearer token for principal [${user}]...`);

      let bearerToken = currentSession && currentSession.user.username === user ? currentSession.token : null;

      if (!bearerToken) {
        const authResponse = await fetch('/api/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username: user, password: 'ZeroTrust_2026' })
        });

        const authData = await authResponse.json();

        if (authData.mfaRequired && authData.mfaSessionId && authData.demoTotpCode) {
          const mfaRes = await fetch('/api/auth/mfa/verify', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              mfaSessionId: authData.mfaSessionId,
              mfaChallengeId: authData.mfaSessionId,
              code: authData.demoTotpCode,
              method: 'authenticator'
            })
          });
          const mfaData = await mfaRes.json();
          if (mfaData.success && mfaData.token) {
            bearerToken = mfaData.token;
          }
        } else if (authData.success && authData.token) {
          bearerToken = authData.token;
        }

        if (!bearerToken) {
          addTerminalLog('error', `[ERROR] Identity token signature rejected: ${authData.error || 'Access Denied'}`);
          setIsFiring(false);
          fetchOverview();
          return;
        }
      }

      addTerminalLog(
        'success',
        `[SUCCESS] Bearer token verified for [${user}]. Signature: ${bearerToken.substring(0, 20)}...`
      );
      addTerminalLog(
        'get',
        `[TRANSIT] Intercepting request for target serverless endpoint: /api/${route}...`
      );

      const pipelineResponse = await fetch(`/api/${route}`, {
        method: 'GET',
        headers: {
          Authorization: `Bearer ${bearerToken}`
        }
      });

      const pipelineData = await pipelineResponse.json();
      const latencyMs = pipelineData.metrics?.verification_latency_ms
        ?? pipelineResponse.headers.get('x-verification-latency-ms')
        ?? pipelineResponse.headers.get('x-security-verification-duration-ms');

      if (latencyMs !== undefined && latencyMs !== null) {
        addTerminalLog(
          'metric',
          `[LATENCY MONITOR] Edge Verification Pipeline Overhead: ${latencyMs} ms (Captured via high-res performance.now() timer).`
        );
      }

      if (pipelineData.metrics?.rateLimitExceeded || pipelineData.metrics?.eventType === 'ABNORMAL_REQUEST_RATE') {
        addTerminalLog(
          'alert',
          `[RATE LIMIT ALERT] ABNORMAL_REQUEST_RATE: Frequency exceeded 10 req/min threshold. Risk score penalized +20%.`
        );
      }

      if (pipelineData.metrics?.failClosed) {
        addTerminalLog(
          'alert',
          `[FAIL-CLOSED GUARANTEE] Critical security pipeline exception handled: Request immediately BLOCKED with 100% Critical Risk score.`
        );
      }

      if (pipelineResponse.status === 200) {
        addTerminalLog('metric', `[METRIC] Security Clearance: STATUS 200 (OK - ALLOWED).`);
        addTerminalLog('success', `[RESPONSE DATA]: ${JSON.stringify(pipelineData, null, 2)}`);
      } else {
        if (pipelineResponse.status === 401) {
          const isExplicitRevocation = String(pipelineData.error || pipelineData.detail || '').toLowerCase().includes('revoked');
          if (isExplicitRevocation) {
            addTerminalLog('alert', '[SESSION REVOKED] Token invalidated at database level by Administrator. Session terminated.');
            if (currentSession && currentSession.user.username === user) {
              setCurrentSession(null);
            }
          } else {
            addTerminalLog('alert', `[UNAUTHORIZED 401] Access rejected by edge authorizer: ${pipelineData.error || pipelineData.detail || 'Invalid clearance'}`);
          }
        }
        addTerminalLog(
          'alert',
          `[ALERT] Security Firewall Intercept: STATUS ${pipelineResponse.status} (BLOCKED).`
        );
        addTerminalLog('error', `[THREAT REASON]: ${pipelineData.error || pipelineData.detail || 'Access Suspended'}`);
        if (pipelineData.metrics) {
          addTerminalLog(
            'metric',
            `[CALCULATED TOTAL RISK]: ${pipelineData.metrics.riskScore}% (Cutoff: ${policyConfig.maxRiskThreshold}%) | Threat Signature: ${pipelineData.metrics.threatReason}`
          );
        }
      }

      await fetchOverview();
    } catch (e: any) {
      addTerminalLog(
        'error',
        `[CRITICAL EXCEPTION] Connection timed out or endpoint target unreachable. Detail: ${e?.message || String(e)}`
      );
    } finally {
      setIsFiring(false);
    }
  };

  // Reset database to initial seed
  const handleReset = async () => {
    setIsResetting(true);
    try {
      const res = await fetch('/api/system/reset', { method: 'POST' });
      if (res.ok) {
        addTerminalLog('info', `[SYSTEM] Database reset to initial baseline schema & mock data.`);
        await fetchOverview();
      } else {
        addTerminalLog('error', `[SYSTEM] Failed to reset baseline state.`);
      }
    } catch (err: any) {
      addTerminalLog('error', `[SYSTEM] Reset operation failed: ${err?.message || String(err)}`);
    } finally {
      setIsResetting(false);
    }
  };

  // Clear audit logs
  const handleClearLogs = async () => {
    try {
      const res = await fetch('/api/system/clearLogs', { method: 'POST' });
      if (res.ok) {
        setLogs([]);
        addTerminalLog('info', `[SYSTEM] Audit logs cleared.`);
      } else {
        addTerminalLog('error', `[SYSTEM] Failed to clear audit ledger.`);
      }
    } catch (err: any) {
      addTerminalLog('error', `[SYSTEM] Clear logs operation failed: ${err?.message || String(err)}`);
    }
  };

  // Add rule
  const handleAddRule = async (current: string, next: string) => {
    try {
      const res = await fetch('/api/system/rules', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ current_function: current, allowed_next_function: next })
      });
      if (res.ok) {
        await fetchOverview();
        addTerminalLog('success', `[SYSTEM] Added sequential execution rule: ${current} -> ${next}`);
      } else {
        addTerminalLog('error', `[SYSTEM] Failed to add sequential rule.`);
      }
    } catch (err: any) {
      addTerminalLog('error', `[SYSTEM] Add rule failed: ${err?.message || String(err)}`);
    }
  };

  // Delete rule
  const handleDeleteRule = async (id: number) => {
    try {
      const res = await fetch(`/api/system/rules/${id}`, { method: 'DELETE' });
      if (res.ok) {
        await fetchOverview();
        addTerminalLog('info', `[SYSTEM] Rule ID #${id} removed from architectural policy.`);
      } else {
        addTerminalLog('error', `[SYSTEM] Failed to remove rule #${id}.`);
      }
    } catch (err: any) {
      addTerminalLog('error', `[SYSTEM] Rule removal failed: ${err?.message || String(err)}`);
    }
  };

  // Inline Real-Time Dynamic User Registration & Login
  const handleInlineRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inlineUsername.trim()) return;
    setInlineLoading(true);
    setInlineMsg(null);

    try {
      const clean = inlineUsername.trim().toLowerCase().replace(/\s+/g, '_');
      const res = await fetch('/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: clean,
          password: 'ZeroTrust_2026',
          role: inlineRole,
          base_risk_score: Number(inlineRisk)
        })
      });
      const data = await res.json();

      if (res.ok && data.success) {
        const newUser: User = {
          id: data.user?.id || `usr_${clean}`,
          username: clean,
          password_hash: 'ZeroTrust_2026',
          role: inlineRole,
          base_risk_score: Number(inlineRisk),
          status: data.user?.status || 'APPROVED'
        };

        const newSession: AuthSession = {
          user: newUser,
          token: data.token || `zt_jwt_${clean}_${Date.now().toString(36)}`,
          loginTime: new Date().toLocaleTimeString(),
          expiresInSeconds: 3600
        };

        setCurrentSession(newSession);
        setSelectedUser(clean);
        setUsers(prev => {
          if (prev.some(u => u.username === clean)) return prev;
          return [...prev, newUser];
        });

        setInlineMsg({ type: 'success', text: `Identity [${clean}] provisioned and activated in real-time!` });
        setInlineUsername('');
        addTerminalLog('success', `[IAM] Real-time user [${clean}] (${inlineRole}) provisioned with base risk ${inlineRisk}%.`);
      } else {
        setInlineMsg({ type: 'error', text: data.error || 'Failed to register identity.' });
      }
    } catch (err: any) {
      setInlineMsg({ type: 'error', text: err?.message || 'Registration failed.' });
    } finally {
      setInlineLoading(false);
    }
  };

  const handleQuickSwitchUser = async (targetUser: User) => {
    try {
      const res = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: targetUser.username, password: 'ZeroTrust_2026', skipMfa: true })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        const session: AuthSession = {
          user: targetUser,
          token: data.token || `zt_jwt_${targetUser.username}_${Date.now().toString(36)}`,
          loginTime: new Date().toLocaleTimeString(),
          expiresInSeconds: 3600
        };
        setCurrentSession(session);
        setSelectedUser(targetUser.username);
        addTerminalLog('info', `[IAM] Active session switched to: ${targetUser.username} (${targetUser.role})`);

        // Automatically guide the user to their role-appropriate tab if current tab is forbidden
        if (targetUser.role === 'Guest' && (activeTab === 'admin' || activeTab === 'developer' || activeTab === 'iam' || activeTab === 'architecture' || activeTab === 'overview' || activeTab === 'interceptor' || activeTab === 'health')) {
          setActiveTab('guest');
        } else if (targetUser.role === 'Developer' && (activeTab === 'admin' || activeTab === 'iam' || activeTab === 'overview' || activeTab === 'guest' || activeTab === 'health' || activeTab === 'interceptor')) {
          setActiveTab('developer');
        } else if (targetUser.role === 'Admin' && (activeTab === 'guest' || activeTab === 'developer')) {
          setActiveTab('admin');
        }
      } else {
        addTerminalLog('error', `[IAM] Failed to authenticate principal: ${data?.error || 'Unknown error'}`);
      }
    } catch (e: any) {
      addTerminalLog('error', `[IAM] Quick switch failed: ${e?.message || String(e)}`);
    }
  };

  // Real-time Session Revocation Endpoint Call (Admin Only)
  const handleRevokeSession = async (username: string) => {
    try {
      addTerminalLog('post', `[IAM REVOCATION] Requesting real-time session termination for principal [${username}]...`);
      const res = await fetch('/api/auth/revoke-session', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${currentSession?.token || 'zt_jwt_secops_admin_k7x9'}`
        },
        body: JSON.stringify({
          username,
          reason: 'Terminated in real-time by SecOps Administrator via User Database'
        })
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to revoke session');
      }
      addTerminalLog('alert', `[IAM REVOCATION] 🚫 Administrator revoked active session for [${username}]. Token invalidated in real-time.`);
      await fetchOverview();

      // If the administrator revoked their own session or active session matches target, terminate locally
      if (currentSession?.user?.username.toLowerCase() === username.toLowerCase()) {
        addTerminalLog('error', `[IAM SESSION TERMINATED] Active principal session has been revoked. Console locked.`);
        setCurrentSession(null);
      }
    } catch (err: any) {
      addTerminalLog('error', `[IAM REVOCATION FAILED] ${err?.message || String(err)}`);
      throw err;
    }
  };

  const handleLogout = () => {
    setCurrentSession(null);
    addTerminalLog('alert', '[IAM GATEWAY] Principal signed out. All role-gated interfaces locked.');
  };

  const handleGatewayLogin = (session: AuthSession, isNewUser?: boolean) => {
    console.log('%c[AUTH_FLOW] 🚀 handleGatewayLogin invoked:', 'color: #3b82f6; font-weight: bold;', {
      user: session?.user?.username,
      role: session?.user?.role,
      hasToken: Boolean(session?.token),
      isNewUser: Boolean(isNewUser),
      timestamp: new Date().toISOString()
    });

    if (!session || !session.token || !session.user) {
      console.error('[AUTH_FLOW] ❌ Aborting login transition: Session token or user payload missing:', session);
      addTerminalLog('error', '[IAM GATEWAY ERROR] Incomplete session token provided.');
      return;
    }

    // Atomically transition session state in React
    setCurrentSession(session);
    setSelectedUser(session.user.username);

    if (isNewUser) {
      setUsers(prev => {
        if (prev.some(u => u.username === session.user.username)) return prev;
        return [...prev, session.user];
      });
    }

    // Role-guided navigation routing
    if (session.user.role === 'Guest') {
      setActiveTab('guest');
    } else if (session.user.role === 'Developer') {
      setActiveTab('developer');
    } else {
      setActiveTab('admin');
    }

    addTerminalLog('success', `[IAM GATEWAY] Authenticated as ${session.user.username} with role '${session.user.role}'.`);
    addTerminalLog('info', `[ZERO-TRUST SESSION] Cryptographic JWT issued. High-assurance clearance granted.`);
  };

  const handleDirectInvokeFromAdmin = async (endpoint: string) => {
    const cleanRoute = endpoint.replace('/api/', '');
    const userToInvoke = currentSession?.user?.username || 'secops_admin';
    await handleFirePipeline(userToInvoke, cleanRoute);
  };

  const handleApproveUser = async (username: string) => {
    try {
      const res = await fetch('/api/system/users/approve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username,
          approvedBy: currentSession?.user.username || 'secops_admin'
        })
      });
      if (!res.ok) {
        const d = await res.json();
        throw new Error(d.error || 'Failed to approve user');
      }
      await fetchOverview();
      addTerminalLog('success', `[IAM CLEARANCE] Principal [${username}] has been APPROVED.`);
    } catch (err: any) {
      addTerminalLog('error', `[IAM CLEARANCE] Approval failed: ${err?.message || String(err)}`);
    }
  };

  const handleRejectUser = async (username: string, reason?: string) => {
    try {
      const res = await fetch('/api/system/users/reject', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username,
          reason: reason || 'Access denied by SecOps Administrator.'
        })
      });
      if (!res.ok) {
        const d = await res.json();
        throw new Error(d.error || 'Failed to reject user');
      }
      await fetchOverview();
      addTerminalLog('alert', `[IAM CLEARANCE] Principal [${username}] access request REJECTED.`);
    } catch (err: any) {
      addTerminalLog('error', `[IAM CLEARANCE] Rejection failed: ${err?.message || String(err)}`);
    }
  };

  const handleAddUser = async (userData: any) => {
    const res = await fetch('/api/system/users', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(userData)
    });
    if (!res.ok) {
      const d = await res.json();
      throw new Error(d.error || 'Failed to save identity');
    }
    await fetchOverview();
    addTerminalLog('success', `[IAM DATABASE] Saved identity [${userData.username}] to database.`);
  };

  const handleDeleteUser = async (username: string) => {
    if (username === 'secops_admin') return;
    const res = await fetch(`/api/system/users/${encodeURIComponent(username)}`, { method: 'DELETE' });
    if (res.ok) {
      await fetchOverview();
      addTerminalLog('info', `[IAM DATABASE] Identity [${username}] removed.`);
    }
  };

  const handleBatchSeedUsers = async () => {
    const res = await fetch('/api/system/users/batch-seed', { method: 'POST' });
    if (res.ok) {
      await fetchOverview();
      addTerminalLog('success', `[IAM DATABASE] Seeded enterprise multi-department identities.`);
    }
  };

  const blockedCount = logs.filter(l => l.status === 'BLOCKED').length;

  return (
    <div className={`min-h-screen ${theme === 'light' ? 'bg-[#f8fafc] text-slate-900' : 'bg-slate-950 text-slate-100'} p-4 sm:p-6 lg:p-8 font-sans selection:bg-blue-600/30 selection:text-white transition-colors duration-200`}>
      <div className="max-w-[1600px] mx-auto space-y-8">
        {/* Navigation & Header with Sidebar Drawer Trigger */}
        <Header
          onReset={handleReset}
          onClearLogs={handleClearLogs}
          isResetting={isResetting}
          onOpenDbModal={() => setIsDbModalOpen(true)}
          onOpenCloudGuide={() => setIsCloudGuideOpen(true)}
          currentSession={currentSession}
          onOpenAuthModal={() => setIsAuthModalOpen(true)}
          activeTab={activeTab}
          onSelectTab={setActiveTab}
          onOpenSidebar={() => setIsSidebarOpen(true)}
          logsCount={logs.length}
          usersCount={users.length}
          blockedCount={blockedCount}
          connectionStatus={connectionStatus}
          onLogout={handleLogout}
          onOpenSecurityReport={() => setIsSecurityReportOpen(true)}
          pendingApprovalCount={pendingApprovalCount}
          onOpenUserDatabase={() => setIsUserDbModalOpen(true)}
          onRunCredentialStuffing={handleRunCredentialStuffing}
          onRunLateralMovementDrill={handleRunLateralMovementDrill}
          onToggleEmergencyLockdown={handleToggleEmergencyLockdown}
          isEmergencyLockdownActive={isEmergencyLockdown}
        />

        {/* Glossy Slide-out Sidebar Navigation Drawer */}
        <SidebarNavigation
          isOpen={isSidebarOpen}
          onClose={() => setIsSidebarOpen(false)}
          activeTab={activeTab}
          onSelectTab={(tab) => {
            setActiveTab(tab);
            setIsSidebarOpen(false);
          }}
          currentSession={currentSession}
          logsCount={logs.length}
          usersCount={users.length}
          blockedCount={blockedCount}
          pendingApprovalCount={pendingApprovalCount}
          onOpenCloudGuide={() => setIsCloudGuideOpen(true)}
          onOpenDbModal={() => setIsDbModalOpen(true)}
          onOpenAuthModal={() => setIsAuthModalOpen(true)}
          onOpenSecurityReport={() => setIsSecurityReportOpen(true)}
          onOpenRbacModal={() => setIsRbacModalOpen(true)}
          onLogout={handleLogout}
          onRunCredentialStuffing={handleRunCredentialStuffing}
          onRunLateralMovementDrill={handleRunLateralMovementDrill}
          onToggleEmergencyLockdown={handleToggleEmergencyLockdown}
          isEmergencyLockdownActive={isEmergencyLockdown}
        />

        {/* If no active session, show the Zero-Trust Login Gateway */}
        {!currentSession ? (
          <div className="py-4">
            <ZeroTrustLoginGateway
              users={users}
              onLoginSuccess={handleGatewayLogin}
              onAddTerminalLog={addTerminalLog}
            />
          </div>
        ) : (
          <>
            {/* Real-time Security Anomaly Alert Banner (Admin & Developer) */}
            {currentSession.user.role !== 'Guest' && (
              <AnomalyAlertBanner
                alerts={anomalyAlerts}
                onAcknowledgeAlert={handleAcknowledgeAlert}
                onQuarantineUser={handleQuarantineUser}
                onNavigateToAudit={() => setActiveTab('audit')}
                onNavigateToAdmin={() => setActiveTab('admin')}
              />
            )}

            {/* Dedicated Workspace View with Glossy Transition */}
            <main key={activeTab} className="animate-section-glossy space-y-8 min-h-[520px]">
              {/* Section Identity Kicker - Displays Section and Workspace in Section-Specific Color */}
              <div className={`p-4 rounded-2xl border transition-all duration-300 flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                theme === 'light'
                  ? `${currentSectionMeta.bannerBgLight} ${currentSectionMeta.bannerBorderLight}`
                  : `${currentSectionMeta.bannerBgDark} ${currentSectionMeta.bannerBorderDark}`
              }`}>
                <div className="flex items-center gap-3">
                  <span className={`text-xs font-mono font-bold px-2.5 py-1 rounded-lg border shrink-0 ${
                    theme === 'light' ? currentSectionMeta.tagBadgeLight : currentSectionMeta.tagBadgeDark
                  }`}>
                    SECTION {currentSectionMeta.sectionNumber}
                  </span>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                        {currentSectionMeta.tabName}
                      </h2>
                      <span className="text-slate-400 text-xs hidden sm:inline">·</span>
                      <span className={`text-xs font-semibold hidden sm:inline ${
                        theme === 'light' ? currentSectionMeta.accentTextLight : currentSectionMeta.accentTextDark
                      }`}>
                        {currentSectionMeta.title}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                      {currentSectionMeta.description}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2.5 self-start sm:self-auto shrink-0">
                  <span className={`text-[10px] font-mono font-semibold px-2 py-0.5 rounded border ${
                    theme === 'light' ? currentSectionMeta.tagBadgeLight : currentSectionMeta.tagBadgeDark
                  }`}>
                    {currentSectionMeta.tabRoleTier}
                  </span>
                  <button
                    type="button"
                    onClick={() => setIsSidebarOpen(true)}
                    className="text-xs font-sans font-medium text-slate-500 hover:text-slate-700 dark:hover:text-slate-200 hover:underline cursor-pointer"
                  >
                    All Modules →
                  </button>
                </div>
              </div>

              {/* FEATURE VIEW 0: EXECUTIVE ADMIN COMMAND & SECOPS CENTER */}
              {activeTab === 'admin' && (
              currentSession.user.role === 'Admin' ? (
                <AdminCommandCenter
                  users={users}
                  logs={logs}
                  rules={rules}
                  policyConfig={policyConfig}
                  currentSession={currentSession}
                  onSwitchSession={handleQuickSwitchUser}
                  onUpdatePolicyConfig={handleUpdatePolicyConfig}
                  onResetDatabase={handleReset}
                  onClearLogs={handleClearLogs}
                  onRefreshData={fetchOverview}
                  onAddTerminalLog={addTerminalLog}
                  onDirectInvoke={handleDirectInvokeFromAdmin}
                  isResetting={isResetting}
                  onOpenSecurityReport={() => setIsSecurityReportOpen(true)}
                  onApproveUser={handleApproveUser}
                  onRejectUser={handleRejectUser}
                  onAddUser={handleAddUser}
                  onDeleteUser={handleDeleteUser}
                  onBatchSeedUsers={handleBatchSeedUsers}
                  onOpenUserDatabase={() => setIsUserDbModalOpen(true)}
                />
              ) : (
                <AccessRestrictedCard
                  requiredRole="Admin"
                  currentSession={currentSession}
                  onNavigateToPermitted={() => setActiveTab(currentSession.user.role === 'Developer' ? 'developer' : 'guest')}
                  onReauthenticate={() => setIsAuthModalOpen(true)}
                />
              )
            )}

            {/* FEATURE VIEW: DEVELOPER CLOUD & EDGE WORKBENCH */}
            {activeTab === 'developer' && (
              currentSession.user.role === 'Guest' ? (
                <AccessRestrictedCard
                  requiredRole="Developer"
                  currentSession={currentSession}
                  onNavigateToPermitted={() => setActiveTab('guest')}
                  onReauthenticate={() => setIsAuthModalOpen(true)}
                />
              ) : (
                <DeveloperWorkbench
                  currentSession={currentSession}
                  rules={rules}
                  logs={logs}
                  onFireFunction={handleDirectInvokeFromAdmin}
                  isFiring={isFiring}
                />
              )
            )}

            {/* FEATURE VIEW: NEXT-GEN AI & CLOUD THREAT SENTINEL */}
            {activeTab === 'ai-threats' && (
              <AICloudThreatShield
                currentUsername={currentSession.user.username}
                userRole={currentSession.user.role}
              />
            )}

            {/* FEATURE VIEW: RESTRICTED GUEST WORKSPACE */}
            {activeTab === 'guest' && (
              <GuestPortal
                currentSession={currentSession}
                logs={logs}
                onFireFunction={handleDirectInvokeFromAdmin}
                isFiring={isFiring}
              />
            )}

            {/* FEATURE VIEW 1: HEALTH & RISK ANALYTICS (ADMIN ONLY) */}
            {activeTab === 'health' && (
              currentSession.user.role !== 'Admin' ? (
                <AccessRestrictedCard
                  requiredRole="Admin"
                  currentSession={currentSession}
                  onNavigateToPermitted={() => setActiveTab(currentSession.user.role === 'Developer' ? 'developer' : 'guest')}
                  onReauthenticate={() => setIsAuthModalOpen(true)}
                />
              ) : (
                <div className="space-y-6">
                  <ThreatSummaryCard logs={logs} />
                  <SystemHealthDashboard
                    users={users}
                    logs={logs}
                    policyConfig={policyConfig}
                    onOpenSecurityReport={() => setIsSecurityReportOpen(true)}
                  />
                </div>
              )
            )}

            {/* FEATURE VIEW 2: SECURITY INTERCEPTOR & SIMULATOR (ADMIN ONLY) */}
            {activeTab === 'interceptor' && (
              currentSession.user.role !== 'Admin' ? (
                <AccessRestrictedCard
                  requiredRole="Admin"
                  currentSession={currentSession}
                  onNavigateToPermitted={() => setActiveTab(currentSession.user.role === 'Developer' ? 'developer' : 'guest')}
                  onReauthenticate={() => setIsAuthModalOpen(true)}
                />
              ) : (
                <div className="space-y-6">
                  {/* Live Edge Verification Topology Banner */}
                  <EdgeTopologyGraphic
                    blockedCount={blockedCount}
                    totalRequests={logs.length}
                    isSimulating={isFiring}
                    onTriggerTestPacket={() => handleFirePipeline(selectedUser, selectedRoute)}
                  />

                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                    <div className="lg:col-span-5 xl:col-span-5">
                      <SimulationControl
                        users={users}
                        selectedUser={selectedUser}
                        onSelectUser={setSelectedUser}
                        selectedRoute={selectedRoute}
                        onSelectRoute={setSelectedRoute}
                        onFire={handleFirePipeline}
                        isFiring={isFiring}
                        terminalLogs={terminalLogs}
                        onClearTerminal={() => setTerminalLogs([])}
                        currentSession={currentSession}
                        policyConfig={policyConfig}
                        onUpdatePolicyConfig={handleUpdatePolicyConfig}
                      />
                    </div>

                    <div className="lg:col-span-7 xl:col-span-7 space-y-5">
                      {/* Interceptor Policy Guide Card */}
                      <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-xl font-mono text-xs shadow-sm">
                        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
                          <div className="flex items-center gap-2 text-white font-bold text-sm">
                            <Shield className="w-4 h-4 text-blue-400" />
                            Runtime Interception Architecture
                          </div>
                          <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 font-semibold">
                            Live Enforcement
                          </span>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
                          <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg">
                            <div className="text-slate-400 text-[10px] uppercase font-bold">1. RBAC Guard</div>
                            <div className="text-white font-semibold mt-1">Role Validation</div>
                            <div className="text-[11px] text-slate-400 mt-1">Admin, Developer, Guest clearances checked before function invocation.</div>
                          </div>

                          <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg">
                            <div className="text-slate-400 text-[10px] uppercase font-bold">2. Markov Sequence</div>
                            <div className="text-white font-semibold mt-1">Order Validation</div>
                            <div className="text-[11px] text-slate-400 mt-1">Out-of-order jumps incur a +{policyConfig.sequenceViolationPenalty}% threat penalty.</div>
                          </div>

                          <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg">
                            <div className="text-slate-400 text-[10px] uppercase font-bold">3. Cutoff Firewall</div>
                            <div className="text-white font-semibold mt-1">Risk Threshold</div>
                            <div className="text-[11px] text-slate-400 mt-1">Requests exceeding {policyConfig.maxRiskThreshold}% risk are immediately blocked.</div>
                          </div>
                        </div>

                        {/* Quick Fire Presets */}
                        <div className="p-3 bg-blue-950/20 border border-blue-500/30 rounded-lg text-blue-300">
                          <div className="font-semibold text-white mb-1 flex items-center gap-2">
                            <Sparkles className="w-3.5 h-3.5 text-blue-400" />
                            Simulation Tip:
                          </div>
                          Use the 1-Click Test Scenarios in the left panel to instantly demonstrate legitimate admin flows, privilege escalation attempts, sequence anomalies, and high-risk exploits!
                        </div>
                      </div>

                      {/* Compact Audit Log Stream Preview */}
                      <AuditLogStream
                        logs={logs}
                        onRefresh={fetchOverview}
                        isRefreshing={isRefreshing}
                      />
                    </div>
                  </div>
                </div>
              )
            )}

            {/* FEATURE VIEW 3: AUDIT LEDGER */}
            {activeTab === 'audit' && (
              <div className="space-y-4">
                <AuditLogStream
                  logs={logs}
                  onRefresh={fetchOverview}
                  isRefreshing={isRefreshing}
                />
              </div>
            )}

            {/* FEATURE VIEW 4: IAM & REAL-TIME USER ACCESS (ADMIN ONLY) */}
            {activeTab === 'iam' && (
              currentSession.user.role !== 'Admin' ? (
                <AccessRestrictedCard
                  requiredRole="Admin"
                  currentSession={currentSession}
                  onNavigateToPermitted={() => setActiveTab(currentSession.user.role === 'Developer' ? 'interceptor' : 'guest')}
                  onReauthenticate={() => setIsAuthModalOpen(true)}
                />
              ) : (
                <div className="space-y-6 font-mono">
                  {/* Real-Time Any User Provisioning Card */}
                  <div className="bg-slate-900 border border-slate-800 p-6 rounded-xl shadow-lg">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4 mb-5">
                      <div>
                        <h3 className="text-base font-bold text-white flex items-center gap-2">
                          <UserPlus className="w-5 h-5 text-emerald-400" />
                          Real-Time Any User Onboarding &amp; Sign In
                        </h3>
                        <p className="text-xs text-slate-400 mt-1">
                          Anyone can enter their username in real-time. The server dynamically creates the user with your chosen role and base risk!
                        </p>
                      </div>
                      <span className="text-[10px] px-2.5 py-1 rounded bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 uppercase font-semibold">
                        Zero-Trust Dynamic IAM
                      </span>
                    </div>

                    {inlineMsg && (
                      <div className={`p-3 rounded-lg text-xs mb-4 flex items-center gap-2 ${
                        inlineMsg.type === 'success'
                          ? 'bg-emerald-950/60 border border-emerald-500/40 text-emerald-200'
                          : 'bg-rose-950/60 border border-rose-500/40 text-rose-200'
                      }`}>
                        <Sparkles className="w-4 h-4 shrink-0" />
                        <span>{inlineMsg.text}</span>
                      </div>
                    )}

                    <form onSubmit={handleInlineRegister} className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                          <label className="block text-xs font-semibold text-slate-300 mb-1 uppercase tracking-wider">
                            Identity Handle / Username
                          </label>
                          <input
                            type="text"
                            value={inlineUsername}
                            onChange={(e) => setInlineUsername(e.target.value)}
                            placeholder="e.g. your_name, sec_auditor"
                            className="w-full p-2.5 bg-slate-950 border border-slate-800 text-white text-xs rounded-lg focus:outline-none focus:border-blue-500 font-mono"
                            required
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-semibold text-slate-300 mb-1 uppercase tracking-wider">
                            Assigned RBAC Role
                          </label>
                          <select
                            value={inlineRole}
                            onChange={(e) => setInlineRole(e.target.value as any)}
                            className="w-full p-2.5 bg-slate-950 border border-slate-800 text-white text-xs rounded-lg focus:outline-none focus:border-blue-500 font-mono"
                          >
                            <option value="Admin">Admin (Unrestricted Tier 3)</option>
                            <option value="Developer">Developer (Deploy & Logs Tier 2)</option>
                            <option value="Guest">Guest (Read-Only Tier 1)</option>
                          </select>
                        </div>

                        <div>
                          <div className="flex items-center justify-between mb-1">
                            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
                              Base Risk Score: <span className="text-white font-bold">{inlineRisk}%</span>
                            </label>
                          </div>
                          <input
                            type="range"
                            min="0"
                            max="100"
                            value={inlineRisk}
                            onChange={(e) => setInlineRisk(Number(e.target.value))}
                            className="w-full mt-2 accent-blue-500 cursor-pointer"
                          />
                        </div>
                      </div>

                      <div className="pt-2 flex items-center justify-between">
                        <div className="text-[11px] text-slate-500">
                          Auto-provisions password <code className="text-slate-300">ZeroTrust_2026</code>. Instantly usable in simulator and audit logs.
                        </div>
                        <button
                          type="submit"
                          disabled={inlineLoading}
                          className="px-5 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-2 transition-all shadow-md shadow-emerald-600/20 disabled:opacity-50"
                        >
                          <UserPlus className="w-4 h-4" />
                          {inlineLoading ? 'Provisioning...' : 'Provision & Sign In In Real Time'}
                        </button>
                      </div>
                    </form>
                  </div>

                  {/* Active User Roster Cards */}
                  <div className={`p-6 rounded-2xl shadow-lg border ${theme === 'light' ? 'bg-white border-slate-200' : 'bg-slate-900 border-slate-800'}`}>
                    <div className="flex items-center justify-between border-b pb-4 mb-4 border-slate-200 dark:border-slate-800">
                      <h3 className={`text-sm font-bold flex items-center gap-2 ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}>
                        <UserCheck className="w-4 h-4 text-blue-500" />
                        Active Principals Roster ({users.length})
                      </h3>
                      <span className="text-xs text-slate-400">
                        Click any principal to activate their live session
                      </span>
                    </div>

                    <div className="max-h-[520px] overflow-y-auto scrollbar-thin pr-1.5">
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                        {users.map((u) => {
                          const isCurrent = currentSession?.user.username === u.username;
                          const isUntrusted = u.base_risk_score >= 70;
                          return (
                            <div
                              key={u.id}
                              className={`p-4 rounded-xl border transition-all flex flex-col justify-between ${
                                isCurrent
                                  ? 'bg-blue-950/20 border-blue-500 ring-1 ring-blue-500/50 shadow-sm'
                                  : isUntrusted
                                  ? 'bg-rose-950/20 border-rose-900/60 hover:border-rose-700/80'
                                  : theme === 'light'
                                  ? 'bg-slate-50 border-slate-200 hover:border-slate-300'
                                  : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                              }`}
                            >
                              <div>
                                <div className="flex items-start justify-between mb-2">
                                  <div className={`text-xs font-bold truncate max-w-[150px] ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}>
                                    {u.username}
                                  </div>
                                  {isCurrent && (
                                    <span className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-500 border border-emerald-500/30 font-semibold">
                                      Active
                                    </span>
                                  )}
                                </div>

                                <div className="space-y-1 text-[11px] text-slate-500 dark:text-slate-400">
                                  <div>Role: <span className={`font-semibold ${theme === 'light' ? 'text-slate-700' : 'text-slate-200'}`}>{u.role}</span></div>
                                  <div>
                                    Base Risk:{' '}
                                    <span className={`font-bold ${
                                      u.base_risk_score >= 70 ? 'text-rose-500' :
                                      u.base_risk_score > 20 ? 'text-amber-500' :
                                      'text-emerald-500'
                                    }`}>
                                      {u.base_risk_score}%
                                    </span>
                                  </div>
                                </div>
                              </div>

                              <button
                                type="button"
                                onClick={() => handleQuickSwitchUser(u)}
                                className={`mt-4 w-full py-1.5 px-3 rounded-lg text-xs font-semibold transition-all border ${
                                  isCurrent
                                    ? 'bg-blue-600 text-white border-blue-500'
                                    : theme === 'light'
                                    ? 'bg-white hover:bg-slate-100 text-slate-700 border-slate-300 shadow-xs'
                                    : 'bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border-slate-800'
                                }`}
                              >
                                {isCurrent ? 'Current Identity' : 'Switch To User'}
                              </button>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </div>
              )
            )}

            {/* FEATURE VIEW 5: CLOUD ARCHITECTURE & D1 SCHEMA (ADMIN ONLY) */}
            {activeTab === 'architecture' && (
              currentSession.user.role !== 'Admin' ? (
                <AccessRestrictedCard
                  requiredRole="Admin"
                  currentSession={currentSession}
                  onNavigateToPermitted={() => setActiveTab(currentSession.user.role === 'Developer' ? 'developer' : 'guest')}
                  onReauthenticate={() => setIsAuthModalOpen(true)}
                />
              ) : (
                <div className="space-y-6 font-mono text-xs">
                  {/* Live Interactive Edge Topology Diagram */}
                  <EdgeTopologyGraphic
                    blockedCount={blockedCount}
                    totalRequests={logs.length}
                    isSimulating={isFiring}
                    onTriggerTestPacket={() => handleFirePipeline(selectedUser, selectedRoute)}
                  />

                  {/* Visual Multi-Layer Pipeline Flowchart */}
                  <div className={`p-6 rounded-2xl border shadow-sm ${theme === 'light' ? 'bg-white border-slate-200' : 'bg-slate-900 border-slate-800'}`}>
                    <div className="flex items-center justify-between border-b pb-3 mb-5 border-slate-200 dark:border-slate-800">
                      <h3 className={`text-sm font-bold flex items-center gap-2 ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}>
                        <Layers className="w-4 h-4 text-blue-500" />
                        Edge Verification Pipeline Architecture
                      </h3>
                      <div className="flex items-center gap-2">
                        {currentSession.user.role !== 'Admin' && (
                          <span className="text-[10px] px-2 py-0.5 rounded bg-blue-950 text-blue-300 border border-blue-800">
                            Developer Review Mode
                          </span>
                        )}
                        <span className="text-[10px] text-slate-400">Cloudflare Worker + D1 SQL</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-center">
                      <div className={`p-4 rounded-xl border ${theme === 'light' ? 'bg-slate-50 border-slate-200' : 'bg-slate-950 border-slate-800'}`}>
                        <div className="text-[10px] uppercase font-bold text-slate-500">Step 1</div>
                        <div className={`font-bold mt-1 text-sm ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}>Client Request</div>
                        <div className="text-[11px] text-slate-400 mt-2">HTTP Bearer JWT Token passed in Authorization header</div>
                      </div>

                      <div className={`p-4 rounded-xl border ${theme === 'light' ? 'bg-blue-50 border-blue-200' : 'bg-slate-950 border-blue-500/40'}`}>
                        <div className="text-[10px] uppercase font-bold text-blue-500">Step 2</div>
                        <div className="text-blue-500 font-bold mt-1 text-sm">Edge Interceptor</div>
                        <div className="text-[11px] text-slate-400 mt-2">RBAC evaluation + Markov sequence transition validation</div>
                      </div>

                      <div className={`p-4 rounded-xl border ${theme === 'light' ? 'bg-amber-50 border-amber-200' : 'bg-slate-950 border-amber-500/40'}`}>
                        <div className="text-[10px] uppercase font-bold text-amber-500">Step 3</div>
                        <div className="text-amber-500 font-bold mt-1 text-sm">Risk Scorer</div>
                        <div className="text-[11px] text-slate-400 mt-2">R_final = min(100, Base + Violations). Firewall cut-off: 75%</div>
                      </div>

                      <div className={`p-4 rounded-xl border ${theme === 'light' ? 'bg-emerald-50 border-emerald-200' : 'bg-slate-950 border-emerald-500/40'}`}>
                        <div className="text-[10px] uppercase font-bold text-emerald-500">Step 4</div>
                        <div className="text-emerald-500 font-bold mt-1 text-sm">Audit Commit</div>
                        <div className="text-[11px] text-slate-400 mt-2">Verdict recorded in Cloudflare D1 distributed SQLite table</div>
                      </div>
                    </div>
                  </div>

                  {/* D1 Transition Rules Manager */}
                  <div className={`p-6 rounded-2xl border shadow-sm ${theme === 'light' ? 'bg-white border-slate-200' : 'bg-slate-900 border-slate-800'}`}>
                    <div className="flex items-center justify-between border-b pb-3 mb-4 border-slate-200 dark:border-slate-800">
                      <div>
                        <h3 className={`text-sm font-bold flex items-center gap-2 ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}>
                          <Database className="w-4 h-4 text-blue-500" />
                          Sequential Markov Transition Rules Matrix ({rules.length})
                        </h3>
                        <p className="text-[11px] text-slate-400 mt-0.5">
                          Defines allowed sequential invocation transitions. Non-whitelisted sequences trigger a +{policyConfig.sequenceViolationPenalty}% penalty.
                        </p>
                      </div>
                      {currentSession.user.role !== 'Admin' && (
                        <span className="text-[10px] px-2 py-1 rounded bg-slate-800 text-slate-400 border border-slate-700">
                          Read-Only (Admin Managed)
                        </span>
                      )}
                    </div>

                    {/* Add Rule Form - Admin Only */}
                    {currentSession.user.role === 'Admin' && (
                      <div className={`p-4 rounded-xl border mb-4 flex flex-col sm:flex-row items-center gap-3 ${theme === 'light' ? 'bg-slate-50 border-slate-200' : 'bg-slate-950 border-slate-800'}`}>
                        <div className="flex-1 w-full">
                          <label className="block text-[10px] text-slate-400 uppercase font-bold mb-1">Current Function</label>
                          <input
                            type="text"
                            value={newRuleCurrent}
                            onChange={(e) => setNewRuleCurrent(e.target.value)}
                            className={`w-full p-2 border rounded-lg text-xs ${theme === 'light' ? 'bg-white border-slate-300 text-slate-900' : 'bg-slate-900 border-slate-800 text-white'}`}
                            placeholder="e.g. login, getDashboardMetrics"
                          />
                        </div>
                        <ArrowRight className="w-4 h-4 text-slate-500 shrink-0 hidden sm:block mt-4" />
                        <div className="flex-1 w-full">
                          <label className="block text-[10px] text-slate-400 uppercase font-bold mb-1">Allowed Next Function</label>
                          <input
                            type="text"
                            value={newRuleNext}
                            onChange={(e) => setNewRuleNext(e.target.value)}
                            className={`w-full p-2 border rounded-lg text-xs ${theme === 'light' ? 'bg-white border-slate-300 text-slate-900' : 'bg-slate-900 border-slate-800 text-white'}`}
                            placeholder="e.g. viewSecurityLogs, deployWorkerCode"
                          />
                        </div>
                        <button
                          type="button"
                          onClick={() => handleAddRule(newRuleCurrent, newRuleNext)}
                          className="mt-4 px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg text-xs whitespace-nowrap flex items-center gap-1.5 shadow-sm"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          Add Transition Rule
                        </button>
                      </div>
                    )}

                    {/* Rules List with Scrollbar */}
                    <div className="max-h-[360px] overflow-y-auto scrollbar-thin pr-1 divide-y divide-slate-800">
                      {rules.map((rule) => (
                        <div key={rule.id} className="py-2.5 flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <span className="text-slate-500 font-mono text-[11px]">#{rule.id}</span>
                            <code className="text-blue-400 bg-blue-950/40 px-2 py-0.5 rounded border border-blue-500/20">{rule.current_function}</code>
                            <ArrowRight className="w-3.5 h-3.5 text-slate-600" />
                            <code className="text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-500/20">{rule.allowed_next_function}</code>
                          </div>
                          {currentSession.user.role === 'Admin' && (
                            <button
                              type="button"
                              onClick={() => handleDeleteRule(rule.id)}
                              className="p-1 text-slate-500 hover:text-rose-400 transition-colors"
                              title="Delete rule"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )
            )}

            {/* FEATURE VIEW 6: CONSOLIDATED CONSOLE (EXECUTIVE SYNTHESIS) */}
            {activeTab === 'overview' && (
              currentSession.user.role !== 'Admin' ? (
                <AccessRestrictedCard
                  requiredRole="Admin"
                  currentSession={currentSession}
                  onNavigateToPermitted={() => setActiveTab(currentSession.user.role === 'Developer' ? 'interceptor' : 'guest')}
                  onReauthenticate={() => setIsAuthModalOpen(true)}
                />
              ) : (
                <div className="space-y-8">
                  {/* High-level KPI metrics */}
                  <ThreatSummaryCard logs={logs} />

                  {/* Visual Topology Graphic on Overview */}
                  <EdgeTopologyGraphic
                    blockedCount={blockedCount}
                    totalRequests={logs.length}
                    isSimulating={isFiring}
                    onTriggerTestPacket={() => handleFirePipeline(selectedUser, selectedRoute)}
                  />

                  {/* Health and Risk Analytics */}
                  <SystemHealthDashboard
                    users={users}
                    logs={logs}
                    policyConfig={policyConfig}
                    onOpenSecurityReport={() => setIsSecurityReportOpen(true)}
                  />

                  {/* Quick Jump Action Cards to Individual Workspaces */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
                    <button
                      type="button"
                      onClick={() => setActiveTab('interceptor')}
                      className="glossy-panel glossy-card-hover p-5 rounded-2xl text-left border flex flex-col justify-between group"
                    >
                      <div>
                        <div className="flex items-center justify-between mb-3">
                          <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-blue-500/15 text-blue-400 border border-blue-500/30 font-bold">
                            Live Simulation
                          </span>
                          <Shield className="w-5 h-5 text-blue-400 group-hover:scale-110 transition-transform" />
                        </div>
                        <h4 className="text-sm font-bold text-white mb-1">Runtime Interceptor</h4>
                        <p className="text-xs text-slate-400">
                          Simulate client HTTP packets, test Markov transition sequences, and inspect firewall thresholds.
                        </p>
                      </div>
                      <div className="mt-4 text-xs font-mono font-semibold text-blue-400 flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                        <span>Open Interceptor</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setActiveTab('ai-threats')}
                      className="glossy-panel glossy-card-hover p-5 rounded-2xl text-left border flex flex-col justify-between group"
                    >
                      <div>
                        <div className="flex items-center justify-between mb-3">
                          <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-indigo-500/15 text-indigo-400 border border-indigo-500/30 font-bold">
                            Autonomous Defense
                          </span>
                          <Bot className="w-5 h-5 text-indigo-400 group-hover:scale-110 transition-transform" />
                        </div>
                        <h4 className="text-sm font-bold text-white mb-1">AI Threat Sentinel</h4>
                        <p className="text-xs text-slate-400">
                          Autonomous behavioral anomaly detection, real-time threat neutralization, and heuristic analysis.
                        </p>
                      </div>
                      <div className="mt-4 text-xs font-mono font-semibold text-indigo-400 flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                        <span>Open Sentinel</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setActiveTab('audit')}
                      className="glossy-panel glossy-card-hover p-5 rounded-2xl text-left border flex flex-col justify-between group"
                    >
                      <div>
                        <div className="flex items-center justify-between mb-3">
                          <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 font-bold">
                            {logs.length} Recorded Events
                          </span>
                          <FileText className="w-5 h-5 text-emerald-400 group-hover:scale-110 transition-transform" />
                        </div>
                        <h4 className="text-sm font-bold text-white mb-1">Compliance Audit Ledger</h4>
                        <p className="text-xs text-slate-400">
                          Stream live cryptographic logs, filter by principal or verdict, and export verification records.
                        </p>
                      </div>
                      <div className="mt-4 text-xs font-mono font-semibold text-emerald-400 flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                        <span>Open Audit Stream</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </div>
                    </button>
                  </div>
                </div>
              )
            )}

            {/* FEATURE VIEW 7: SERVERLESS FUNCTION INVENTORY & INVOCATION EXPLORER */}
            {activeTab === 'functions' && (
              <FunctionInventoryExplorer
                logs={logs}
                onFireFunction={async (slug: string) => {
                  await handleFirePipeline(selectedUser, slug);
                }}
                isFiring={isFiring}
              />
            )}

            {/* FEATURE VIEW 8: INCIDENT RESPONSE & CONTAINMENT */}
            {activeTab === 'incidents' && (
              <IncidentManagementConsole
                currentUsername={currentSession?.user.username || 'secops_admin'}
              />
            )}

            {/* FEATURE VIEW 9: ZERO-TRUST API TESTING CONSOLE */}
            {activeTab === 'api-testing' && (
              <ApiTestingConsole />
            )}

            {/* FEATURE VIEW 10: CONFIGURATION & POLICY SETTINGS */}
            {activeTab === 'settings' && (
              <SystemConfigSettingsModal
                isOpen={true}
                isInline={true}
                onClose={() => setActiveTab('admin')}
                policyConfig={policyConfig}
                onUpdatePolicy={async (cfg) => {
                  await handleUpdatePolicyConfig({ ...policyConfig, ...cfg });
                }}
                onResetPolicy={async () => {
                  await handleUpdatePolicyConfig({
                    maxRiskThreshold: 75,
                    sequenceViolationPenalty: 40,
                    enforceStrictSequence: true,
                    globalLockdown: false
                  });
                }}
              />
            )}

            {/* FEATURE VIEW 11: TECHNICAL DOCUMENTATION & VIVA DEFENSE GUIDE */}
            {activeTab === 'docs' && (
              <HelpTechnicalDocsModal
                isOpen={true}
                isInline={true}
                onClose={() => setActiveTab('admin')}
              />
            )}
            </main>
          </>
        )}

        {/* Professional Footer */}
        <footer className="mt-8 pt-4 border-t border-slate-800/80 text-center text-xs text-slate-500 font-mono flex flex-col sm:flex-row items-center justify-between gap-2">
          <div>
            Serverless Security Verification Framework • Enterprise Zero-Trust Edition
          </div>
          <div className="flex items-center gap-4">
            <span className="text-emerald-400 flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
              {users.length} Active Principals
            </span>
            <span className="text-blue-400">Edge Interceptor Active</span>
          </div>
        </footer>
      </div>

      {/* Modals */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        users={users}
        currentSession={currentSession}
        onLoginSuccess={(session, isNewUser) => {
          setCurrentSession(session);
          setSelectedUser(session.user.username);
          if (isNewUser) {
            setUsers(prev => {
              if (prev.some(u => u.username === session.user.username)) return prev;
              return [...prev, session.user];
            });
          }
          addTerminalLog('success', `[IAM] Authenticated as ${session.user.username} (${session.user.role})`);
        }}
        onLogout={() => {
          setCurrentSession(null);
          addTerminalLog('alert', `[IAM] Active session terminated.`);
        }}
      />

      <SecurityArchitectureModal
        isOpen={isDbModalOpen}
        onClose={() => setIsDbModalOpen(false)}
        users={users}
        rules={rules}
        onAddRule={handleAddRule}
        onDeleteRule={handleDeleteRule}
      />

      <CloudGuideModal
        isOpen={isCloudGuideOpen}
        onClose={() => setIsCloudGuideOpen(false)}
      />

      <SecurityReportModal
        isOpen={isSecurityReportOpen}
        onClose={() => setIsSecurityReportOpen(false)}
        users={users}
        logs={logs}
        rules={rules}
        policyConfig={policyConfig}
        currentSession={currentSession}
        onAddTerminalLog={addTerminalLog}
      />

      <UserDatabaseModal
        isOpen={isUserDbModalOpen}
        onClose={() => setIsUserDbModalOpen(false)}
        users={users}
        onApproveUser={handleApproveUser}
        onRejectUser={handleRejectUser}
        onAddUser={handleAddUser}
        onDeleteUser={handleDeleteUser}
        onBatchSeed={handleBatchSeedUsers}
        onRevokeSession={handleRevokeSession}
      />

      <RbacManagementModal
        isOpen={isRbacModalOpen}
        onClose={() => setIsRbacModalOpen(false)}
        currentUserRole={currentSession?.user.role || 'Guest'}
        currentUsername={currentSession?.user.username || ''}
        users={users}
        onRoleAssigned={async () => {
          await fetchOverview();
        }}
      />

      <SystemConfigSettingsModal
        isOpen={isConfigModalOpen}
        onClose={() => setIsConfigModalOpen(false)}
        policyConfig={policyConfig}
        onUpdatePolicy={async (cfg) => {
          await handleUpdatePolicyConfig({ ...policyConfig, ...cfg });
        }}
        onResetPolicy={async () => {
          await handleUpdatePolicyConfig({
            maxRiskThreshold: 75,
            sequenceViolationPenalty: 40,
            enforceStrictSequence: true,
            globalLockdown: false
          });
        }}
      />

      <HelpTechnicalDocsModal
        isOpen={isDocsModalOpen}
        onClose={() => setIsDocsModalOpen(false)}
      />
    </div>
  );
}
